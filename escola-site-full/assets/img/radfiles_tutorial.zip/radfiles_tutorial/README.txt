Files for the RADIANCE Tutorial
===============================

./README.txt         - This file
objects/arrows.rad   - Three arrows in red, green, and blue pointing in x, y, and z,
                       resp. The arrows are 1 unit long and joint at position 0,0,0.
                       Put them into your model if you get lost with the position,
                       orientation or scale of your objects.
objects/chair.rad    - Simple chair, including material definitions
materials/course.mat - Some material definitions
./lux.plt            - To plot illuminance readings taken with rtrace
skies/sky.rad        - Sky geometry (You need to create sky.mat with the
                       materials for sky and sun yourself! Use gensky for this.)
objects/table.rad    - Simple table, including material definitions
./room.rif           - Start with this file if you would like to experiment
                       with the rad or trad programs

Please refer to appendices A.1 and A.2 of the tutorial PDF for
file extensions and a recommended directory structure for your projects.

Axel Jacobs, Jan 2012

