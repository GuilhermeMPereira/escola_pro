Files for the Radiance Cookbook
===============================

README.txt
  This file

time_of_day.bash 
  script for generating one image for each hour of the day

cal/pcyl.cal
  cal file for cylindrical projection.  Slightly modified from Raphael
  Compagnon's original version.

data/ERCO_88100000_1xQR-CBC35_20W_38deg.ies
  IES distribution for ERCO luminaire

docs/gimbal_specs.pdf
  Product description for ERCO luminaire

materials/room_thick_walls.mat
  Material definition for room with thick walls

materials/course.mat
  Material definitions for simple room (from Radiance Tutorial)

objects/room_thick_walls.rad
  Radiance geometry of room with thin walls (from Radiance Tutorial)

objects/window.rad
  illum window for the test room

objects/room.rad
  Radiance geometry of room with thick walls

weather/GBR_London.Gatwick_IWEC.epw
  EnergyPlus weather file for DaySim

Axel Jacobs, Mar 2010

