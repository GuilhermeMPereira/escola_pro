#!/bin/bash

# Bash shell script to produce time_of_day image sequences
# with RADIANCE.
# Taken from Rendering with RADIANCE, 
# Modified by Axel Jacobs, 21-03-2004

# The arguments for gensky and the label
day=23
month=03
coords="-a 52 -o 0 -m 0"

# The ambient parameters
ab=2
ad=512
as=128
ar=64
aa=0.2
av="0 0 0"

for hour in {04..22}; do
# An intermediate sky makes the sunpatches less bright
skypar="$month $day +$hour +i $coords"
gambv=$(gensky $skypar \
		| rcalc -i '# Ground ambient level: ${ga}' -e '$1=ga')
psign -h 16 $day/$month $hour:00 > temp/label.pic
# If it's night outside, do nothing
if [ "$gambv" != "0" ] ; then
	ambpar="-ab $ab -ad $ad -as $as -ar $ar -aa $aa -av $av"

	# Generate the sky
	gensky $skypar > temp/sky_temp.mat
	# Compile the octree
	oconv -i script.oct temp/sky_temp.mat sky.rad> temp/temp.oct

	# Render the picture
	# Use an ambient file for the calculation
	rm temp/temp.amb
	rpict -vf nice.vf $ambpar -af temp/temp.amb -x 32 -y 32 \
			temp/temp.oct > /dev/null
	rpict -vf nice.vf $ambpar -af temp/temp.amb -t 180 \
			-x 800 -y 600 temp/temp.oct \
			| pfilt -1 -x /2 -y /2 -e .2 \
			| pcompos - 0 0 temp/label.pic 0 0 \
			> images/$hour.pic
fi
done

cd images

# Convert all images to JPEG format
for file in $(ls *.pic) ; do 
    echo $file 
    ra_pict $file > temp.pict
    convert temp.pict $(basename $file pic)jpg
done 

# Tidy up
rm temp.pict

#EOF
